--
-- PostgreSQL database dump
--

\restrict fvMUNt0Ig5KZDHkT1tdSzw2j98syFfc0xL1bKNBdZAqDPnTiRjwNpmRekGBWawb

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: admin_users_role_enum; Type: TYPE; Schema: public; Owner: reboulstore
--

CREATE TYPE public.admin_users_role_enum AS ENUM (
    'ADMIN',
    'SUPER_ADMIN'
);


ALTER TYPE public.admin_users_role_enum OWNER TO reboulstore;

--
-- Name: order_emails_emailtype_enum; Type: TYPE; Schema: public; Owner: reboulstore
--

CREATE TYPE public.order_emails_emailtype_enum AS ENUM (
    'order_received',
    'order_confirmed',
    'order_shipped',
    'order_delivered',
    'order_cancelled'
);


ALTER TYPE public.order_emails_emailtype_enum OWNER TO reboulstore;

--
-- Name: orders_status_enum; Type: TYPE; Schema: public; Owner: reboulstore
--

CREATE TYPE public.orders_status_enum AS ENUM (
    'pending',
    'paid',
    'processing',
    'confirmed',
    'shipped',
    'delivered',
    'cancelled',
    'refunded'
);


ALTER TYPE public.orders_status_enum OWNER TO reboulstore;

--
-- Name: users_role_enum; Type: TYPE; Schema: public; Owner: reboulstore
--

CREATE TYPE public.users_role_enum AS ENUM (
    'CLIENT',
    'ADMIN',
    'SUPER_ADMIN'
);


ALTER TYPE public.users_role_enum OWNER TO reboulstore;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.addresses (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "userId" uuid NOT NULL,
    street character varying NOT NULL,
    city character varying NOT NULL,
    "postalCode" character varying NOT NULL,
    country character varying DEFAULT 'France'::character varying NOT NULL,
    "additionalInfo" character varying,
    "isDefault" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.addresses OWNER TO reboulstore;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.admin_users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    "firstName" character varying,
    "lastName" character varying,
    role public.admin_users_role_enum DEFAULT 'ADMIN'::public.admin_users_role_enum NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_users OWNER TO reboulstore;

--
-- Name: brands; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.brands (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    "logoUrl" character varying(500),
    "megaMenuImage1" character varying(500),
    "megaMenuImage2" character varying(500),
    "megaMenuVideo1" character varying(500),
    "megaMenuVideo2" character varying(500),
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.brands OWNER TO reboulstore;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.cart_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "cartId" uuid NOT NULL,
    "variantId" uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cart_items OWNER TO reboulstore;

--
-- Name: carts; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.carts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "sessionId" character varying(255) NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.carts OWNER TO reboulstore;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    "imageUrl" character varying(500),
    "videoUrl" character varying(500),
    "sizeChart" jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.categories OWNER TO reboulstore;

--
-- Name: images; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.images (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "productId" uuid NOT NULL,
    url character varying(500) NOT NULL,
    "publicId" character varying(255),
    alt character varying(255),
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.images OWNER TO reboulstore;

--
-- Name: order_emails; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.order_emails (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "orderId" uuid NOT NULL,
    "emailType" public.order_emails_emailtype_enum NOT NULL,
    "recipientEmail" character varying NOT NULL,
    subject character varying(255) NOT NULL,
    sent boolean DEFAULT true NOT NULL,
    "errorMessage" text,
    "sentAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.order_emails OWNER TO reboulstore;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.orders (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "cartId" uuid,
    status public.orders_status_enum DEFAULT 'pending'::public.orders_status_enum NOT NULL,
    total numeric(10,2) NOT NULL,
    "customerInfo" jsonb NOT NULL,
    "userId" uuid,
    "shippingAddress" jsonb,
    "billingAddress" jsonb,
    "paymentIntentId" character varying,
    items jsonb,
    "trackingNumber" character varying,
    "paidAt" timestamp without time zone,
    "shippedAt" timestamp without time zone,
    "deliveredAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.orders OWNER TO reboulstore;

--
-- Name: products; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    "categoryId" uuid NOT NULL,
    "shopId" uuid,
    "brandId" uuid,
    materials text,
    "careInstructions" text,
    "madeIn" character varying(100),
    "customSizeChart" jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.products OWNER TO reboulstore;

--
-- Name: shops; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.shops (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    "shippingPolicy" jsonb,
    "returnPolicy" jsonb,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "contactInfo" jsonb,
    "stripeConfig" jsonb
);


ALTER TABLE public.shops OWNER TO reboulstore;

--
-- Name: users; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    "firstName" character varying,
    "lastName" character varying,
    phone character varying,
    role public.users_role_enum DEFAULT 'CLIENT'::public.users_role_enum NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO reboulstore;

--
-- Name: variants; Type: TABLE; Schema: public; Owner: reboulstore
--

CREATE TABLE public.variants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "productId" uuid NOT NULL,
    color character varying(100) NOT NULL,
    size character varying(50) NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    sku character varying(100) NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.variants OWNER TO reboulstore;

--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.addresses (id, "userId", street, city, "postalCode", country, "additionalInfo", "isDefault", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.admin_users (id, email, password, "firstName", "lastName", role, "isActive", "createdAt", "updatedAt") FROM stdin;
d82c02dd-7112-4a82-9c00-448b3897321a	admin@reboul.com	$2b$10$hF1aitOhX7VN72LO.Qioo.kxATKruqvpKvQ2hQxCho7Lw5.V68Tau	Admin	Reboul	SUPER_ADMIN	t	2025-12-16 23:03:08.937018	2025-12-16 23:03:08.937018
85e4fffc-0096-4e78-92c6-2c36d52a7ed5	admin@test.com	$2b$10$50nMu8t6tKZnpOvcqztR.eaFU8nnRjapt1R8E2f9902mg7A5zvGFO	Admin	Test	SUPER_ADMIN	t	2025-12-17 00:12:54.847347	2025-12-17 00:12:54.847347
\.


--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.brands (id, name, slug, description, "logoUrl", "megaMenuImage1", "megaMenuImage2", "megaMenuVideo1", "megaMenuVideo2", "createdAt", "updatedAt") FROM stdin;
672241d4-57ec-4d04-a2ec-03fd3ce8c4d1	Marque Test Upload 1765942773880	marque-test-upload-1765942773880	Marque créée pour tester les uploads Cloudinary	https://res.cloudinary.com/dxen69pdo/image/upload/v1765942776/admin-uploads/images/file_emve6p.jpg	https://res.cloudinary.com/dxen69pdo/image/upload/v1765942781/admin-uploads/images/file_n5rfri.jpg	https://res.cloudinary.com/dxen69pdo/image/upload/v1765942785/admin-uploads/images/file_xkywzg.jpg	https://res.cloudinary.com/dxen69pdo/video/upload/v1765942808/admin-uploads/videos/file_c4kdhw.mp4	https://res.cloudinary.com/dxen69pdo/video/upload/v1765942819/admin-uploads/videos/file_ogwkar.mp4	2025-12-17 03:40:24.288604	2025-12-17 03:40:24.288604
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.cart_items (id, "cartId", "variantId", quantity, "createdAt") FROM stdin;
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.carts (id, "sessionId", "createdAt", "updatedAt") FROM stdin;
b178b45a-2f39-45c4-aac2-99fa83940fdf	session_1765928895242_ontl2cafv	2025-12-16 23:48:19.888122	2025-12-16 23:48:19.888122
da563ad2-bc69-420a-b38c-047442d08cb4	session_1765928910732_dt8y1nmje	2025-12-16 23:48:31.269714	2025-12-16 23:48:31.269714
c259c87b-9be6-4181-803c-84fc116fe20f	session_1765929191626_5wufm6wbt	2025-12-16 23:53:13.513845	2025-12-16 23:53:13.513845
24545578-6ed3-45c0-9c6d-9aae81575f2f	session_1765932269391_teul42luq	2025-12-17 00:44:32.178749	2025-12-17 00:44:32.178749
fb0ea940-098b-46f4-ac9a-c84975c34463	session_1765942681276_6m4xgy2db	2025-12-17 03:38:05.049766	2025-12-17 03:38:05.049766
b1fb63c3-75fc-4d5a-b3a1-d5eb6b24a0c7	session_1766191505335_h9qb3nup8	2025-12-20 00:45:05.81861	2025-12-20 00:45:05.81861
f96acf5c-663f-4a89-a09e-baee1fe589a8	session_1766200508162_nz3cccz6k	2025-12-20 03:15:08.729569	2025-12-20 03:15:08.729569
3b5a539d-d5a2-4591-ad1d-d05cd1ecd774	session_1766201307750_2f1tudfyv	2025-12-20 03:28:27.899734	2025-12-20 03:28:27.899734
f74dfea2-a217-416a-b4da-1bdb414b953d	session_1766210880700_xesn3vw6k	2025-12-20 06:08:01.448705	2025-12-20 06:08:01.448705
6a629244-6f8d-442a-8e7c-97bd151f6a27	session_1766906179924_i9cm86lec	2025-12-28 07:16:24.670085	2025-12-28 07:16:24.670085
425cfd99-e1db-4073-92dc-b056a1d3f21d	session_1766906350729_oq4ey45y7	2025-12-28 07:19:11.147356	2025-12-28 07:19:11.147356
8ae76c73-1122-4a16-b4bb-5922b2b4ae36	session_1766906355542_hxquspxo6	2025-12-28 07:19:15.788683	2025-12-28 07:19:15.788683
ce599350-d41f-41d7-9836-8bee411675e3	session_1766906372826_pmt451gbt	2025-12-28 07:19:33.564071	2025-12-28 07:19:33.564071
8c3a7e7c-3dd7-43b8-8199-c91548e0316f	session_1766906418892_h2pvque7r	2025-12-28 07:20:19.964931	2025-12-28 07:20:19.964931
8cf92355-91e6-4278-9b0d-4f5a0aacbd20	session_1766906431997_b3ydjduij	2025-12-28 07:20:32.903617	2025-12-28 07:20:32.903617
2a481d37-d2bc-4dfe-84f8-370b5c2e76fb	session_1766906436916_b7o6v9q86	2025-12-28 07:20:37.412774	2025-12-28 07:20:37.412774
91271897-e7f8-4774-9a71-1282262cec61	session_1766906441855_82zfqdnzd	2025-12-28 07:20:42.292544	2025-12-28 07:20:42.292544
fda399d1-7ba9-4ff3-9de3-f2b7904c74e0	session_1766906446571_3vqud8pli	2025-12-28 07:20:46.962253	2025-12-28 07:20:46.962253
fc1b0938-4d12-4eae-8a58-adda07231660	session_1766906471153_du6nxnyfz	2025-12-28 07:21:13.80883	2025-12-28 07:21:13.80883
6719aa8b-9f36-4353-9365-f37fa94d7008	session_1766906563697_hbavgp2sz	2025-12-28 07:22:45.036585	2025-12-28 07:22:45.036585
6b0c4df5-e468-45be-9499-310dcfc042e4	session_1766906571413_g9uh0tikt	2025-12-28 07:22:52.187469	2025-12-28 07:22:52.187469
67ccaf9a-bc3d-4761-bca4-ab8f25cea74a	session_1766906597105_61f8v9fju	2025-12-28 07:23:17.564789	2025-12-28 07:23:17.564789
fdeaece3-0fad-42f8-831f-3d8fc3942263	session_1766906665189_n9s69qt97	2025-12-28 07:24:26.880562	2025-12-28 07:24:26.880562
4dfef92f-ec69-4f2b-b294-dac8e03e6ff0	session_1766906748034_4c17sphjr	2025-12-28 07:25:49.84	2025-12-28 07:25:49.84
42129811-ae97-48e6-ad05-a79aa456a862	session_1766907214014_slxxi2o3s	2025-12-28 07:33:35.566677	2025-12-28 07:33:35.566677
ff3e5854-0ce5-4939-bfb5-aadc0618c7f9	session_1766907468184_qgohitel2	2025-12-28 07:37:48.618825	2025-12-28 07:37:48.618825
92cd6507-a2b0-49a7-a8f2-ca7194f1c8fb	session_1766907476803_4bbydsu10	2025-12-28 07:37:58.367193	2025-12-28 07:37:58.367193
1b6c558e-6370-45c8-a890-5f36cdf4448c	session_1766907512004_0m69vdy2q	2025-12-28 07:38:34.114891	2025-12-28 07:38:34.114891
401722db-f19a-443f-aae7-bb6b373efcc7	session_1766907631384_sfeb1xgta	2025-12-28 07:40:32.982163	2025-12-28 07:40:32.982163
b6cfc7dd-cb49-4eab-a82b-bcadd9949f35	session_1766907723438_ztcq4w5ad	2025-12-28 07:42:04.503371	2025-12-28 07:42:04.503371
eb764238-688e-4db3-b7aa-ab6f211e2702	session_1766907823654_sqmr7ifx0	2025-12-28 07:43:46.57701	2025-12-28 07:43:46.57701
36f6ef3d-ec08-42b9-87a7-1e7ce2a268d8	session_1766908225816_qczv7m8d7	2025-12-28 07:50:27.638563	2025-12-28 07:50:27.638563
c6c8b0df-d039-413f-b625-615af2853a64	session_1766908517988_6fj4haskc	2025-12-28 07:55:19.025088	2025-12-28 07:55:19.025088
511a8973-95ef-4d00-874a-a7332188449f	session_1766954550892_edyfu0sp4	2025-12-28 20:42:35.669379	2025-12-28 20:42:35.669379
d20a3986-6d19-4f95-aedc-7305073e30b2	session_1766954976268_g67m021vj	2025-12-28 20:49:38.372558	2025-12-28 20:49:38.372558
61d69474-077e-46ed-ac35-ae5a27a70f2c	session_1766954976984_27kk8lcoq	2025-12-28 20:49:38.923344	2025-12-28 20:49:38.923344
25853d02-6315-4cde-bfee-7faef7e403cd	session_1766955626256_zee17hhfh	2025-12-28 21:00:28.540271	2025-12-28 21:00:28.540271
4d11ba0c-79ed-48ae-88c8-0512e89eee24	session_1766955627998_pg34clfgg	2025-12-28 21:00:29.060931	2025-12-28 21:00:29.060931
c22af3af-76fb-474d-8bf7-28790a71d05f	session_1766955650892_tmf9j2ws9	2025-12-28 21:00:54.471116	2025-12-28 21:00:54.471116
5d20ebec-150c-4419-857d-12120644c1f3	session_1766956458158_vx5ic38bu	2025-12-28 21:14:21.233609	2025-12-28 21:14:21.233609
adc95491-fbc4-4d14-9ce5-b9fcbd28165c	session_1766956972556_r5j8ixc32	2025-12-28 21:22:57.887745	2025-12-28 21:22:57.887745
da5a1bb6-baa2-4556-8d25-7037d18e7f16	session_1766957208187_7zld29hx9	2025-12-28 21:26:51.138158	2025-12-28 21:26:51.138158
632385c0-6524-4071-8129-3b176ec56a91	session_1766957344409_bp9rfp0dc	2025-12-28 21:29:07.293775	2025-12-28 21:29:07.293775
2a331c8f-0e38-48be-87ef-92c930529bb5	session_1766957856556_9hseo0i0f	2025-12-28 21:37:38.394794	2025-12-28 21:37:38.394794
a3f98e52-229e-4475-bce0-b489d4df1af2	session_1766957964511_73raetpjg	2025-12-28 21:39:33.276955	2025-12-28 21:39:33.276955
363fd5b4-3096-4d6c-80f8-02f1470bb68f	session_1766958046865_nuqhnbv70	2025-12-28 21:40:54.209393	2025-12-28 21:40:54.209393
6f96ad1e-6644-4075-bfa2-a0af3770f867	session_1766958348763_9ksid97m8	2025-12-28 21:45:53.148448	2025-12-28 21:45:53.148448
4cbbc8d5-49cb-4c42-bb24-d6f79a00cd8e	session_1766959315926_9vmythoyh	2025-12-28 22:01:56.721513	2025-12-28 22:01:56.721513
5841f8de-df60-4012-b132-8e15c6d6c9df	session_1766959832939_34lpb2vqn	2025-12-28 22:10:34.481977	2025-12-28 22:10:34.481977
4dd2e41b-7092-4d2f-ba7b-65a0b4127797	session_1766960138673_51gh2z4jm	2025-12-28 22:15:42.779338	2025-12-28 22:15:42.779338
42b87d6c-e63a-4479-b7f1-041077b4e128	session_1766960675245_4wrd1zwqp	2025-12-28 22:24:36.735841	2025-12-28 22:24:36.735841
7530b5e8-824a-4c32-9e5b-26b867e9033c	session_1766961238456_xobia9m80	2025-12-28 22:34:00.102037	2025-12-28 22:34:00.102037
05c90cd8-125a-4796-99d4-2ffdc1c2d73c	session_1766961469264_i23ofq14s	2025-12-28 22:37:50.21767	2025-12-28 22:37:50.21767
0c897c11-9c57-47f7-9053-7556c677a206	session_1766961528116_1f29s1zxk	2025-12-28 22:38:52.373849	2025-12-28 22:38:52.373849
5e2c4b83-112c-4468-9dc3-9d8e17149aaf	session_1766961555271_8n38ex4mf	2025-12-28 22:39:16.679272	2025-12-28 22:39:16.679272
4bb44dff-7bcf-4b66-9bd6-2a19ee98ebd8	session_1766961572256_1orp8evyc	2025-12-28 22:39:33.117095	2025-12-28 22:39:33.117095
781f996e-487e-436b-9b29-25756eeab540	session_1766961576980_8jvst81hz	2025-12-28 22:39:37.477022	2025-12-28 22:39:37.477022
86b5fc0d-354a-413e-b191-bb1dae4c53b0	session_1766977415059_bspnnwqkn	2025-12-29 03:03:35.860752	2025-12-29 03:03:35.860752
4f5ea250-e111-4c77-8b70-c83f56e5448b	session_1766977878096_7q2taucyq	2025-12-29 03:11:19.88127	2025-12-29 03:11:19.88127
95248dfb-afe3-4a8e-a292-6803158c3f42	session_1766978574323_nrk5u9a29	2025-12-29 03:23:02.435288	2025-12-29 03:23:02.435288
f4ceccf6-b0dc-4b96-8ee6-c504e4c783b2	session_1766979557783_h3dpweb4q	2025-12-29 03:39:21.326533	2025-12-29 03:39:21.326533
2d00b84d-0ef5-4d8d-925d-f4a21ca2d08d	session_1766979571522_dka62bq2q	2025-12-29 03:39:33.705676	2025-12-29 03:39:33.705676
d36e5b6e-93c5-41b1-b802-7d8b4e952ce2	session_1766979906328_bxy0u91hp	2025-12-29 03:45:08.944769	2025-12-29 03:45:08.944769
af06f6cc-0c67-475e-af49-7e4e07f8d318	session_1766980620964_xbkgol8j7	2025-12-29 03:57:03.281833	2025-12-29 03:57:03.281833
628942c1-47f4-43b6-a50d-97bccde43b39	session_1766980960644_1bz582ei5	2025-12-29 04:02:42.436319	2025-12-29 04:02:42.436319
0b39be8b-7ea8-498c-93c5-06d11e297f1b	session_1766981327478_klrhl460a	2025-12-29 04:08:48.60654	2025-12-29 04:08:48.60654
656a373a-ce4b-4522-95b8-dcf7725bc91e	session_1766982818546_axnkn9egd	2025-12-29 04:33:41.88703	2025-12-29 04:33:41.88703
c74c9f0f-33ed-4934-b769-6ae3dddd1634	session_1766984510962_hdz5f4369	2025-12-29 05:01:54.086611	2025-12-29 05:01:54.086611
f33e0b8a-00ad-47d9-86a5-670cd1d49563	session_1766989852193_3b7581sy9	2025-12-29 06:30:59.192894	2025-12-29 06:30:59.192894
33f5594d-3858-4784-9361-b7af590b77f1	session_1766990337687_pg0zm9b5z	2025-12-29 06:39:00.259937	2025-12-29 06:39:00.259937
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.categories (id, name, slug, description, "imageUrl", "videoUrl", "sizeChart", "createdAt", "updatedAt") FROM stdin;
5aea1d17-ea47-43d8-be8c-fbab4bcf7f7f	Kids	kids	Collection Kids	\N	\N	\N	2025-12-16 23:52:26.590183	2025-12-16 23:52:26.590183
e6e1f34d-fc45-4489-acb2-4f91d10a47f9	Vestes	vestes	Collection Vestes	\N	\N	\N	2025-12-16 23:52:29.437156	2025-12-16 23:52:29.437156
eadb341f-404d-4d4b-a38a-50ea9416592d	Adult	adult	Collection Adult	\N	\N	\N	2025-12-16 23:52:55.558974	2025-12-16 23:52:55.558974
3bfe1fd0-dbcf-411d-9b25-990cfc77380c	Sneakers	sneakers	Collection Sneakers	\N	\N	\N	2025-12-16 23:52:56.715906	2025-12-16 23:52:56.715906
4f4b99d7-c68c-49ab-9454-e8fde92c9ae6	Catégorie Test Upload 1765942745620	categorie-test-upload-1765942745620	Catégorie créée pour tester les uploads Cloudinary	\N	https://res.cloudinary.com/dxen69pdo/video/upload/v1765942749/admin-uploads/videos/file_w6kveo.mp4	\N	2025-12-17 03:39:13.792289	2025-12-17 03:39:13.792289
f856d6b9-9d3c-4f71-b2d2-97dacb663986	Catégorie Test Upload 1765942758503	categorie-test-upload-1765942758503	Catégorie créée pour tester les uploads Cloudinary	https://res.cloudinary.com/dxen69pdo/image/upload/v1765942761/admin-uploads/images/file_qmq7sf.jpg	https://res.cloudinary.com/dxen69pdo/video/upload/v1765942765/admin-uploads/videos/file_agqp8y.mp4	\N	2025-12-17 03:39:29.178508	2025-12-17 03:39:29.178508
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.images (id, "productId", url, "publicId", alt, "order", "createdAt") FROM stdin;
\.


--
-- Data for Name: order_emails; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.order_emails (id, "orderId", "emailType", "recipientEmail", subject, sent, "errorMessage", "sentAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.orders (id, "cartId", status, total, "customerInfo", "userId", "shippingAddress", "billingAddress", "paymentIntentId", items, "trackingNumber", "paidAt", "shippedAt", "deliveredAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.products (id, name, description, price, "categoryId", "shopId", "brandId", materials, "careInstructions", "madeIn", "customSizeChart", "createdAt", "updatedAt") FROM stdin;
6e79d001-6e6c-4783-af2b-db44663fc6b9	Jeans Slim Fit	Jeans slim fit délavé	79.99	eadb341f-404d-4d4b-a38a-50ea9416592d	\N	\N	\N	\N	\N	\N	2025-12-17 00:30:50.817392	2025-12-17 00:30:50.817392
e2a1f5dc-fe98-49ac-ad62-ed2b173939a8	Sweat à Capuche Gris	Sweat à capuche oversize	69.99	eadb341f-404d-4d4b-a38a-50ea9416592d	\N	\N	\N	\N	\N	\N	2025-12-17 00:31:00.054011	2025-12-17 00:31:00.054011
6097999a-0405-4009-b5cf-371068da6b39	Short Cargo Vert	Short cargo militaire vert	59.99	eadb341f-404d-4d4b-a38a-50ea9416592d	\N	\N	\N	\N	\N	\N	2025-12-17 00:31:11.149874	2025-12-17 00:31:11.149874
a33b3556-fb40-4390-8ae2-a7952fd58339	Baskets High Top	Baskets montantes en cuir	139.99	3bfe1fd0-dbcf-411d-9b25-990cfc77380c	\N	\N	\N	\N	\N	\N	2025-12-17 00:31:20.392496	2025-12-17 00:31:20.392496
6f342e07-ae0a-4ffa-90fd-71340fa71eab	Polo Blanc	Polo en coton piqué	54.99	eadb341f-404d-4d4b-a38a-50ea9416592d	\N	\N	\N	\N	\N	\N	2025-12-17 00:31:29.630407	2025-12-17 00:31:29.630407
77f6b532-97cf-4e71-a570-c08af1f379a9	Chaussures Bébé	Chaussures souples pour bébé	34.99	5aea1d17-ea47-43d8-be8c-fbab4bcf7f7f	\N	\N	\N	\N	\N	\N	2025-12-17 00:31:38.821696	2025-12-17 00:31:38.821696
f64f040d-bdf6-4cd9-a782-0834c1381f42	Sneakers White Low (ÉDITÉ)	Sneakers en cuir blanc, semelle épaisse - Modifié par le script de test	99.00	3bfe1fd0-dbcf-411d-9b25-990cfc77380c	\N	\N	\N	\N	\N	\N	2025-12-17 00:30:32.33937	2025-12-17 00:32:09.499768
917cc58f-e008-4998-814d-a22db1d93b11	Veste Bomber Noir (MODIFIÉ)	Veste bomber style militaire	99.00	e6e1f34d-fc45-4489-acb2-4f91d10a47f9	\N	\N	\N	\N	\N	\N	2025-12-17 00:30:41.543407	2025-12-17 00:32:20.891088
\.


--
-- Data for Name: shops; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.shops (id, name, slug, description, "shippingPolicy", "returnPolicy", "createdAt", "updatedAt", "contactInfo", "stripeConfig") FROM stdin;
b6d8f8df-77e5-4322-8e86-e96b1cdcc5c5	Reboul Store 2.0	reboul	\N	\N	\N	2025-12-20 00:49:53.211833	2025-12-20 00:51:09.317732	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.users (id, email, password, "firstName", "lastName", phone, role, "isVerified", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: variants; Type: TABLE DATA; Schema: public; Owner: reboulstore
--

COPY public.variants (id, "productId", color, size, stock, sku, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: admin_users PK_06744d221bb6145dc61e5dc441d; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT "PK_06744d221bb6145dc61e5dc441d" PRIMARY KEY (id);


--
-- Name: products PK_0806c755e0aca124e67c0cf6d7d; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "PK_0806c755e0aca124e67c0cf6d7d" PRIMARY KEY (id);


--
-- Name: images PK_1fe148074c6a1a91b63cb9ee3c9; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT "PK_1fe148074c6a1a91b63cb9ee3c9" PRIMARY KEY (id);


--
-- Name: categories PK_24dbc6126a28ff948da33e97d3b; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "PK_24dbc6126a28ff948da33e97d3b" PRIMARY KEY (id);


--
-- Name: order_emails PK_281a1a97148f960cd9927b722d0; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.order_emails
    ADD CONSTRAINT "PK_281a1a97148f960cd9927b722d0" PRIMARY KEY (id);


--
-- Name: shops PK_3c6aaa6607d287de99815e60b96; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT "PK_3c6aaa6607d287de99815e60b96" PRIMARY KEY (id);


--
-- Name: variants PK_672d13d1a6de0197f20c6babb5e; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.variants
    ADD CONSTRAINT "PK_672d13d1a6de0197f20c6babb5e" PRIMARY KEY (id);


--
-- Name: cart_items PK_6fccf5ec03c172d27a28a82928b; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "PK_6fccf5ec03c172d27a28a82928b" PRIMARY KEY (id);


--
-- Name: orders PK_710e2d4957aa5878dfe94e4ac2f; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "PK_710e2d4957aa5878dfe94e4ac2f" PRIMARY KEY (id);


--
-- Name: addresses PK_745d8f43d3af10ab8247465e450; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT "PK_745d8f43d3af10ab8247465e450" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: brands PK_b0c437120b624da1034a81fc561; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT "PK_b0c437120b624da1034a81fc561" PRIMARY KEY (id);


--
-- Name: carts PK_b5f695a59f5ebb50af3c8160816; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT "PK_b5f695a59f5ebb50af3c8160816" PRIMARY KEY (id);


--
-- Name: variants UQ_36c4c7a3b994abc268f8ebbf489; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.variants
    ADD CONSTRAINT "UQ_36c4c7a3b994abc268f8ebbf489" UNIQUE (sku);


--
-- Name: categories UQ_420d9f679d41281f282f5bc7d09; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "UQ_420d9f679d41281f282f5bc7d09" UNIQUE (slug);


--
-- Name: shops UQ_8c28ec876676eeb1dcb65c01b7f; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT "UQ_8c28ec876676eeb1dcb65c01b7f" UNIQUE (slug);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: brands UQ_b15428f362be2200922952dc268; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT "UQ_b15428f362be2200922952dc268" UNIQUE (slug);


--
-- Name: admin_users UQ_dcd0c8a4b10af9c986e510b9ecc; Type: CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT "UQ_dcd0c8a4b10af9c986e510b9ecc" UNIQUE (email);


--
-- Name: orders FK_151b79a83ba240b0cb31b2302d1; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "FK_151b79a83ba240b0cb31b2302d1" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: products FK_51a281693ebef6fa8729de39381; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_51a281693ebef6fa8729de39381" FOREIGN KEY ("shopId") REFERENCES public.shops(id);


--
-- Name: cart_items FK_5a27845bc2d79be6f1fa3d2c036; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "FK_5a27845bc2d79be6f1fa3d2c036" FOREIGN KEY ("variantId") REFERENCES public.variants(id);


--
-- Name: images FK_7af50639264735c79e918af6089; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT "FK_7af50639264735c79e918af6089" FOREIGN KEY ("productId") REFERENCES public.products(id);


--
-- Name: order_emails FK_937a6492bf7fa26cb43cb2c8e88; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.order_emails
    ADD CONSTRAINT "FK_937a6492bf7fa26cb43cb2c8e88" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: addresses FK_95c93a584de49f0b0e13f753630; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT "FK_95c93a584de49f0b0e13f753630" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: variants FK_bdbfe33a28befefa9723c355036; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.variants
    ADD CONSTRAINT "FK_bdbfe33a28befefa9723c355036" FOREIGN KEY ("productId") REFERENCES public.products(id);


--
-- Name: orders FK_d7b6b269e131a5287bd05da4a51; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "FK_d7b6b269e131a5287bd05da4a51" FOREIGN KEY ("cartId") REFERENCES public.carts(id);


--
-- Name: products FK_ea86d0c514c4ecbb5694cbf57df; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_ea86d0c514c4ecbb5694cbf57df" FOREIGN KEY ("brandId") REFERENCES public.brands(id);


--
-- Name: cart_items FK_edd714311619a5ad09525045838; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "FK_edd714311619a5ad09525045838" FOREIGN KEY ("cartId") REFERENCES public.carts(id);


--
-- Name: products FK_ff56834e735fa78a15d0cf21926; Type: FK CONSTRAINT; Schema: public; Owner: reboulstore
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_ff56834e735fa78a15d0cf21926" FOREIGN KEY ("categoryId") REFERENCES public.categories(id);


--
-- PostgreSQL database dump complete
--

\unrestrict fvMUNt0Ig5KZDHkT1tdSzw2j98syFfc0xL1bKNBdZAqDPnTiRjwNpmRekGBWawb

